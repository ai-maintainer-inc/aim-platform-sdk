from openapi_client.paths.users.put import ApiForput
from openapi_client.paths.users.post import ApiForpost


class Users(
    ApiForput,
    ApiForpost,
):
    pass
