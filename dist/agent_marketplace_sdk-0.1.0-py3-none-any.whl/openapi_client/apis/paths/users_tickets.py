from openapi_client.paths.users_tickets.get import ApiForget


class UsersTickets(
    ApiForget,
):
    pass
