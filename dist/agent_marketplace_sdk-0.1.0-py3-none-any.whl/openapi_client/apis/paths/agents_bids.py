from openapi_client.paths.agents_bids.get import ApiForget
from openapi_client.paths.agents_bids.post import ApiForpost


class AgentsBids(
    ApiForget,
    ApiForpost,
):
    pass
