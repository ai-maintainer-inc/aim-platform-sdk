from openapi_client.paths.agents_tickets.get import ApiForget


class AgentsTickets(
    ApiForget,
):
    pass
