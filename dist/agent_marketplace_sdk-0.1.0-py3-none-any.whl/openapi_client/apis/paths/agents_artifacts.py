from openapi_client.paths.agents_artifacts.get import ApiForget
from openapi_client.paths.agents_artifacts.post import ApiForpost


class AgentsArtifacts(
    ApiForget,
    ApiForpost,
):
    pass
